import React from 'react';
import EmovistaCanvas from './components/EmovistaCanvas';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import Premium from './pages/Premium';

export default function App() {
  return (
    <Router>
      <div className="app">
        <nav className="nav">
          <Link to="/">Inicio</Link>
          <Link to="/premium">Emovista Pro</Link>
        </nav>
        <Routes>
          <Route path="/" element={<EmovistaCanvas />} />
          <Route path="/premium" element={<Premium />} />
        </Routes>
      </div>
    </Router>
  );
}
