import React from 'react';

export default function Premium() {
  return (
    <div className="premium">
      <h2>Emovista Pro</h2>
      <p>Gracias por tu interés en Emovista Pro. Pronto podrás acceder a funciones como:</p>
      <ul>
        <li>Guardar tus obras emocionales</li>
        <li>Estilos de arte personalizados</li>
        <li>Exportación en alta resolución</li>
      </ul>
      <p>Disponible muy pronto.</p>
    </div>
  );
}
