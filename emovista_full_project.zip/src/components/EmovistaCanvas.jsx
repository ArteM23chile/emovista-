import React from 'react';

export default function EmovistaCanvas() {
  return (
    <div className="canvas">
      <h1>Bienvenido a Emovista</h1>
      <p>Tu rostro es arte. Observa cómo se transforma.</p>
      <button onClick={() => window.location.href='/premium'}>Desbloquear Emovista Pro</button>
    </div>
  );
}
