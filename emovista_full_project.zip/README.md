# Emovista

**Emovista** convierte tus emociones en arte visual usando reconocimiento facial.  
Reacciona a tu estado de ánimo en tiempo real para crear obras únicas.

## Versión Pro
Haz clic en "Emovista Pro" dentro de la app para conocer las funciones premium que estarán disponibles.

## Cómo usar
1. Clona este repositorio.
2. Instala dependencias con `npm install`.
3. Corre `npm run dev` para ver la app localmente.
4. Sube este repo a GitHub y conéctalo con Vercel para publicarlo.

## Licencia

Todos los derechos reservados. Ver `LICENSE.txt` para más detalles.
